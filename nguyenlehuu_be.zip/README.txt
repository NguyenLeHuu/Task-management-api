step 1: open terminal
step 2: install dependency by "npm i"
step 3: run command "npm run dev"
step 4: tap to link on the screen to redirect api doc or open link "http://localhost:3000/api-docs/" in browser